
public interface ArgParser {
	String parse(String str);
}
