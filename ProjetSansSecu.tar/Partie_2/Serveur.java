import java.net.*;
import java.io.*;
import java.util.Scanner;

public class Serveur{
  public static void main(String[] args){
    new TCPServeur();
  }
}
