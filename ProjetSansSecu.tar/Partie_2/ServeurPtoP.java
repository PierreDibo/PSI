import java.net.*;
import java.io.*;
import java.util.HashMap;


public class ServeurPtoP implements Runnable{

  private ServerSocket server;

  public static HashMap<String, Contact > contactables = new HashMap<String, Contact>();

  public static HashMap<String, Contact> getMapContact(){return contactables;}



  public ServeurPtoP(int port_client){
    try{
       this.server = new ServerSocket(port_client);
    }catch(Exception e){
      System.out.println(e);
      e.printStackTrace();
    }
  }

  public void run(){
    try{
      while(true){
        Socket socket=server.accept();
        ServicePtoP serv = new ServicePtoP(socket);
        Thread t=new Thread(serv);
        t.start();
      }
    }
    catch(Exception e){
      System.out.println(e);
      e.printStackTrace();
    }
  }
}
