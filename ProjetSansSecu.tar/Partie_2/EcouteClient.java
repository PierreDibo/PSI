import java.net.*;
import java.io.*;
import java.util.HashMap;


public class EcouteClient implements Runnable{

  private Socket socket;
  private PrintWriter pw;
  private BufferedReader br;

  public EcouteClient( Socket s, PrintWriter pw, BufferedReader br){
    try{
      this.socket = s;
      this.pw = pw;
      this.br = br;
    }catch(Exception e){
      System.out.println(e);
      e.printStackTrace();
    }
  }

  public void run(){
    try {
      boolean looping = true;
      while(looping) {
        int delimiters = 0;
        String message = "";
        while(delimiters < 3){
          int charCode = this.br.read();
          if(charCode == 42){
            delimiters++;
          }
          else{
            delimiters = 0;
          }
          message += ((char)charCode) + "";
        }
        looping = route(message);
      }
      this.br.close();
      this.pw.close();
      this.socket.close();
      //tcp_rout.scanNext();
    }
    catch (IOException e) {
      //e.printStackTrace();
    }
  }

  boolean route(String message) {
    UnparsedMessage unparsedMessage = new UnparsedMessage(message);
    MessageType messageType = unparsedMessage.getType();
    String[] args = unparsedMessage.getArgs();
    if(messageType == null || args == null) {
      //tcp_rout.scanNext();
      return true;
    }
    switch(messageType) {

      case CALL_OPEN_SUCCESS:
      System.out.println("\nCommunication possible avec: " + args[0]);
      ServeurPtoP.getMapContact().put(args[0], new Contact(socket));
      //tcp_rout.scanNext();
      break;


      case CALL_OPEN_ERROR:
      System.out.println("\nImpossible d'initialiser la communication");
      //tcp_rout.scanNext();
      break;

      case SENT:
      //tcp_rout.scanNext();
      break;

      case CALL_CLOSE_OK:
      System.out.println("\nCommunication fermée");
      ServeurPtoP.getMapContact().remove(args[0]);
      System.out.println("\n");
      return false;

      default:
      //tcp_rout.scanNext();
      break;
    }
    return true;
  }
}
